# from testing_LG import LG
# from conbim_LGSVL import LG
# import testingApollo as lg
import json
import socket

import lgsvl
import scenario as lg
import again as new_lg
from prettytable import PrettyTable
from environs import Env

if __name__ == '__main__':

    # lg = LG()
    # for i in range(1):
    #     lg.create_ego_and_connect(1,2)
    #     # lg.get_physics()
    #     # phy = [2500, 30, 0.32, 8299, 800, 3000, 450, 39.4, 4, 1, 0.4, 0.8]
    #     # lg.set_npc_follow()
    #     # lg.set_physics(phy)
    #     lg.set_Pedestrian()
    #     result = lg.run()
    #     lg.destory()

    env = Env()
    sim = lgsvl.Simulator(env.str("LGSVL__SIMULATOR_HOST", lgsvl.wise.SimulatorSettings.simulator_host),
                          env.int("LGSVL__SIMULATOR_PORT", lgsvl.wise.SimulatorSettings.simulator_port))
    HOST = '192.168.50.51'
    PORT = 6007
    ADDR = (HOST, PORT)
    ss = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ss.connect(ADDR)
    # phy = [2464.735, 31.225, 0.389, 9196.576, 675.049, 2548.653, 447.44, 39.66, 4.011, 0.951, 0.369, 0.799]
    # phy = [2486.865, 30.209, 0.388, 9199.67, 677.442, 2532.785, 452.656, 41.22, 4.306, 0.973, 0.426, 0.8
    # phy = [2480.135, 38.872, 0.381, 10078.097, 727.729, 2511.77, 469.96, 39.446, 3.273, 1.199, 0.433, 0.935]
    # phy = [2468.837, 37.618, 0.389, 9480.663, 663.614, 2510.535, 469.237, 32.019, 3.503, 1.204, 0.431, 0.898]
    # phy = [2450.3378385381843, 47.80138635049733, 0.3897212386940487, 9177.467820024973, 800.3310506768481,
    #        2549.9153641788585, 448.61585053524396, 38.785226639115855, 4.023814949424705, 1.0047427048490907,
    #        0.4256608789042954, 0.8013893537948116]
    # phy = [2451.5652456446383, 29.043897450588197, 0.3897483465760235, 8344.50332369824, 795.6910973247062,
    #        2539.9872257104253, 448.2948777035322, 38.79830674323425, 3.9711192905258996, 0.9532722137876074,
    #        0.3927130400148535, 0.7834389881679151]

    phy = [2120.0, 30.0, 0.35, 8299.0, 800.0, 3000.0, 450.0, 39.4 ,4.0, 1.0, 0.4, 0.8]
    for i in range(1):
        r = lg.main(phy, env, sim, ss)
        # result, TET, TIT, average_acc = lg.main(phy, env, sim, ego, npc, ss)
        # print("distance:", r)
