# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2022/4/16 19:07
# @Author  : Chengjie
# @File    : test_zdt.py
from jmetal.algorithm.multiobjective import NSGAII
from jmetal.operator import SBXCrossover, PolynomialMutation
from jmetal.problem import ZDT1
from jmetal.util.termination_criterion import StoppingByEvaluations
import dill as pickle

problem = ZDT1()
#
algorithm = NSGAII(
    problem=problem,
    population_size=100,
    offspring_population_size=100,
    mutation=PolynomialMutation(probability=1.0 / problem.number_of_variables, distribution_index=20),
    crossover=SBXCrossover(probability=1.0, distribution_index=20),
    termination_criterion=StoppingByEvaluations(max_evaluations=25000)
)
# pickle_file = open('zdt.pkl','rb')
# al = pickle.load(pickle_file)
# pickle_file.close()
# algorithm = al

temp = ['sm', 'll', 'yz', 'pq']
try:
    algorithm.run()
except Exception as e:
    print("error:", e)
    print(e.args)
    save_file = open('zdt.pkl', 'wb')
    # save_temp = open('temp.pkl', 'wb')
    pickle.dump(algorithm, save_file)
    # pickle.dump(temp, save_temp)
    save_file.close()
    # save_temp.close()
    print("SVAE")
except KeyboardInterrupt:
    print(" you do it")

finally:
    print("finally")

from jmetal.util.solution import get_non_dominated_solutions, print_function_values_to_file, \
    print_variables_to_file

front = get_non_dominated_solutions(algorithm.get_result())

# save to files
print_function_values_to_file(front, 'FUN.NSGAII.ZDT1')
print_variables_to_file(front, 'VAR.NSGAII.ZDT1')

from jmetal.lab.visualization import Plot

plot_front = Plot(title='Pareto front approximation', axis_labels=['x', 'y'])
plot_front.plot(front, label='NSGAII-ZDT1', filename='NSGAII-ZDT1', format='png')
