from environs import Env
import time
import os
import lgsvl
from prettytable import PrettyTable
from lgsvl.geometry import Vector, Transform

env = Env()
table = PrettyTable()
sim = lgsvl.Simulator(env.str("LGSVL__SIMULATOR_HOST", lgsvl.wise.SimulatorSettings.simulator_host),
                      env.int("LGSVL__SIMULATOR_PORT", lgsvl.wise.SimulatorSettings.simulator_port))
if sim.current_scene == lgsvl.wise.DefaultAssets.map_borregasave:
    sim.reset()
else:
    sim.load(lgsvl.wise.DefaultAssets.map_borregasave)

    # sim.reset()
    # sim.load(lgsvl.wise.DefaultAssets.map_borregasave)
table = PrettyTable()
spawns = sim.get_spawn()

state = lgsvl.AgentState()
state.transform = spawns[0]
state.transform.position = Vector(100.646987915039, -4.49, -45)
# ego = sim.add_agent(name="47b529db-0593-4908-b3e7-4b24a32a0f70", agent_type=lgsvl.AgentType.EGO, state=state)
ego = sim.add_agent(lgsvl.wise.DefaultAssets.ego_lincoln2017mkz_apollo5, agent_type=lgsvl.AgentType.EGO, state=state)

# npc stop 3.25--------------------------------------

state_npc = lgsvl.AgentState()
state_npc.transform = spawns[0]
state_npc.transform.position = Vector(165.646987915039, -4.49, -63)
npc = sim.add_agent("Sedan", lgsvl.AgentType.NPC, state_npc)
state_npc.transform.position = Vector(165.646987915039, -4.49, -60)
npc_1 = sim.add_agent("Sedan", lgsvl.AgentType.NPC, state_npc)

# ------------------------------------------------------
# ---------pes-set--------before run----------------------------
# state_p = lgsvl.AgentState()
# state_p.transform = spawns[0]
# tr = Transform(state_p.transform)
# tr.position = Vector(165.646987915039, -4.49, -70)  # right
#
# wp = []
# wp.append(lgsvl.WalkWaypoint(tr.position, idle=0, speed=2))
# tr.position = Vector(165.646987915039, -4.49, -63)  # left
# wp.append(lgsvl.WalkWaypoint(tr.position, idle=0, speed=1.3))
# state.transform.position = wp[0].position
# p = sim.add_agent("Pamela", lgsvl.AgentType.PEDESTRIAN, state_p)
#
#
# def on_waypoint(agent, index):
#     print("Waypoint {} reached".format(index))
#
#
# p.on_waypoint_reached(on_waypoint)
# p.follow(wp, True)

# -----------------------------------------------------------------

ego.connect_bridge(env.str("LGSVL__AUTOPILOT_0_HOST", lgsvl.wise.SimulatorSettings.bridge_host),
                   env.int("LGSVL__AUTOPILOT_0_PORT", lgsvl.wise.SimulatorSettings.bridge_port))
# bridge connection
print("Waiting for connection...")
while not ego.bridge_connected:
    time.sleep(1)
print("Get connection!")
# get current parameter
s = ego.state
if s is not None:
    table.add_column('参数', ['angular', 'speed', 'tip', 'mass', 'wheel_mass', 'wheel_radius', 'MaxMotorTorque',
                            'MaxBrakeTorque', 'MinRPM', 'MaxRPM', 'ShiftTime', 'TireDragCoeff', 'WheelDamping',
                            'TractionControlSlipLimit', 'MaxSteeringAngle', 'position'])
    table.add_column('值',
                     [s.angular_velocity, s.velocity, s.tip, s.mass, s.wheel_mass, s.wheel_radius, s.MaxMotorTorque,
                      s.MaxBrakeTorque, s.MinRPM, s.MaxRPM, s.ShiftTime, s.TireDragCoeff, s.WheelDamping,
                      s.TractionControlSlipLimit, s.MaxSteeringAngle, s.position])
    print(table)
    del table

# Dreamview setup
dv = lgsvl.dreamview.Connection(sim, ego, env.str("LGSVL__AUTOPILOT_0_HOST", "192.168.50.51"))
dv.set_hd_map('Borregas Ave')
dv.set_vehicle('Lincoln2017MKZ')
modules = [
    'Localization',
    'Perception',
    'Transform',
    'Routing',
    'Prediction',
    'Planning',
    'Camera',
    'Traffic Light',
    'Control'
]
destination = spawns[0].destinations[0]
dv.setup_apollo(destination.position.x, destination.position.z, modules)

# 3.25 : phy -----0.35 -NO--------before run------change parameter-----
# phy = [2120, 30, 0.35, 450, 3000, 800, 8299, 0.4, 4, 1, 0.8, 39.4]

# phy = [2300, 32, 0.35, 450, 2500, 800, 8299, 0.4, 1, 0.25, 0.8, 39.4]
# x = ego.state
# x.mass = phy[0]
# x.wheel_mass = phy[1]
# x.wheel_radius = phy[2]
# x.MaxMotorTorque = phy[3]
# x.MaxBrakeTorque = phy[4]
# x.MinRPM = phy[5]
# x.MaxRPM = phy[6]
# x.ShiftTime = phy[7]
# x.TireDragCoeff = phy[8]
# x.WheelDamping = phy[9]
# x.TractionControlSlipLimit = phy[10]
# x.MaxSteeringAngle = phy[11]
# ego.state = x
# phy = [2500, 30, 0.32, 8299, 800, 3000, 450, 39.4, 4, 1, 0.4, 0.8]
# x = ego.state
# x.mass = phy[0]
# x.wheel_mass = phy[1]
# x.wheel_radius = phy[2]
# x.MaxRPM = phy[3]
# x.MinRPM = phy[4]
# x.MaxBrakeTorque = phy[5]
# x.MaxMotorTorque = phy[6]
# x.MaxSteeringAngle = phy[7]
# x.TireDragCoeff = phy[8]
# x.WheelDamping = phy[9]
# x.ShiftTime = phy[10]
# x.TractionControlSlipLimit = phy[11]
# ego.state = x
# ----------------------------------------------------------------------
sim.run(time_limit=30.0)

print(ego.state.transform.position)
print(npc.state.transform.position)
print(165 - ego.state.transform.position.x)
print(npc.state.transform.position.x)

#
s = ego.state
table_2 = PrettyTable()
if s is not None:
    table_2.add_column('参数', ['angular', 'speed', 'tip', 'mass', 'wheel_mass', 'wheel_radius', 'MaxMotorTorque',
                              'MaxBrakeTorque', 'MinRPM', 'MaxRPM', 'ShiftTime', 'TireDragCoeff', 'WheelDamping',
                              'TractionControlSlipLimit', 'MaxSteeringAngle', 'position'])
    table_2.add_column('值',
                       [s.angular_velocity, s.velocity, s.tip, s.mass, s.wheel_mass, s.wheel_radius,
                        s.MaxMotorTorque,
                        s.MaxBrakeTorque, s.MinRPM, s.MaxRPM, s.ShiftTime, s.TireDragCoeff, s.WheelDamping,
                        s.TractionControlSlipLimit, s.MaxSteeringAngle, s.position])
    print(table_2)