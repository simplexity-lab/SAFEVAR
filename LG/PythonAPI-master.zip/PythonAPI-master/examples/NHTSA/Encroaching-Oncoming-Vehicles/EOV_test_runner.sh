#!/bin/sh

set -eu

python3 EOV_S_25_20.py
python3 EOV_S_45_40.py
python3 EOV_S_65_60.py